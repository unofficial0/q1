﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketBAL;
using TicketEntity;
using TicketException;

namespace TicketPL
{
    class Program
    {
        private static void PrintMenu()
        {
            string choice1;
            do
            {
                Console.WriteLine("\n***********Ticket Management System ***********");
                Console.WriteLine("1. Add Ticket");              
                Console.WriteLine("2. Search Ticket");
                Console.WriteLine("3. Get all Ticket Details");             
                Console.WriteLine("4. Serielization Data");
                Console.WriteLine("5. Deserilized Data"); 


                int choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                         AddTicket();
                        break;
                    case 2:
                         SearchTicket();
                        break;
                    case 3:
                         ListAllTickets();
                        break;
                    case 4:
                        SerielizedData();
                        break;
                    case 5:
                         Deserializable();
                        break;
                  

                }
                Console.WriteLine("Do you want to contiue(y/n)?");
                choice1 = Console.ReadLine();
            } while ((choice1 == "y"));
            Console.Read();
        }

        /// <summary>
        /// Adding Ticket........
        /// </summary>
        public static void AddTicket()
        {
            try
            {
                Ticketentity ticket = new Ticketentity();
                Console.WriteLine("Enter PNR Number :");
                ticket.PNRNumber = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Source Name :");
                ticket.Source = Console.ReadLine();
                Console.WriteLine("Enter Destination :");
                ticket.Destination = Console.ReadLine();
                Console.WriteLine("Enter Date of Journey :");
                ticket.DateOfJourney =Convert.ToDateTime( Console.ReadLine());

                Console.WriteLine("Enter Date  of Booking :");
                ticket.BookingDate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter Ticket Type :");
                ticket.Type = Console.ReadLine();
                Console.WriteLine("Enter Price of the Ticket :");
                ticket.Price = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter Number Of Tickets :"  );
                ticket.NoOfTickets = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine(ticket.Price * ticket.NoOfTickets);

               
                

                bool StudentAdded = Ticketbal.AddTicket(ticket);
                if (StudentAdded == true)
                {
                    Console.WriteLine("Ticket Added Successfully");
                }
                else
                {
                    throw new TicketNotFoundException("Ticket not added");
                }
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        /// <summary>
        /// Search method based on the PNR number......
        /// </summary>
        public static void SearchTicket()
        {
            int PNRNumber;
            Ticketentity searchTicket;
            try
            {
                Console.WriteLine("Enter PNRNumber to Search:");
                PNRNumber = Convert.ToInt32(Console.ReadLine());
                searchTicket = Ticketbal.SearchticketBAL(PNRNumber);

                if (searchTicket != null)
                {
                    Console.WriteLine("Source Name:" + searchTicket.Source);
                    Console.WriteLine("DestInation Name" + searchTicket.Destination);
                    Console.WriteLine("Date of Journey" + searchTicket.DateOfJourney);

                    Console.WriteLine("Booking Date " + searchTicket.BookingDate);
                    Console.WriteLine("Type" + searchTicket.Type);
                    Console.WriteLine("Price" + searchTicket.Price);
                    Console.WriteLine("No of Tickets" + searchTicket.NoOfTickets);
                }
                else
                {
                    throw new TicketNotFoundException("Ticket not Found");
                }
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// Display all Details......
        /// </summary>

        private static void ListAllTickets()
        {
            try
            {
                List<Ticketentity> TicketList = Ticketbal.GetAll_bal();
                if (TicketList != null && TicketList.Count > 0)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Source\t\tDestination\t\tDateOfJourney\t\tBookingDate\t\tPrice\t\tPNRNumber\t\tType\t\tNoOfTickets");
                    Console.WriteLine("******************************************************************************");
                    foreach (Ticketentity ticket in TicketList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}", ticket.Source, ticket.Destination, ticket.DateOfJourney, ticket.BookingDate, ticket.Price, ticket.PNRNumber,ticket.Type, ticket.NoOfTickets);
                        Console.WriteLine(ticket.Price * ticket.NoOfTickets);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Ticket Details Available");
                }
            }
            catch (TicketNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Serielization...............
        /// </summary>
        public static void SerielizedData()
        {
            try

            {

                


                bool tickettSerialized = Ticketbal.SerializeData();

                if (tickettSerialized)

                    Console.WriteLine("ticket Serialized");

                else

                    Console.WriteLine("ticket not Serialized");


            }

            catch (TicketNotFoundException ex)

            {

                Console.WriteLine(ex.Message);

            }
        }

        /// <summary>
        /// Deserielization...............
        /// </summary>
        public static void Deserializable()
        {
            try

            {

                List<Ticketentity> Ticketlist = Ticketbal.DeserializeData();

                if (Ticketlist != null && Ticketlist.Count > 0)

                {

                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("******************************************************************************");

                    foreach (Ticketentity ticket in Ticketlist)

                    {

                        Console.WriteLine("{0}\t\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}", ticket.PNRNumber, ticket.Source, ticket.Destination, ticket.DateOfJourney, ticket.BookingDate, ticket.Type, ticket.Price, ticket.NoOfTickets);

                    }

                    Console.WriteLine("******************************************************************************");

                }

                else

                {

                    Console.WriteLine("No Serialized Data Available");

                }

            }

            catch (TicketNotFoundException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }

        static void Main(string[] args)
        {
            PrintMenu();
        }
    }
}
