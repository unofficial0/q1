﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketEntity;
using TicketException;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace TicketDAL
{
    public class Ticketdal
    {
        public static List<Ticketentity> tc = new List<Ticketentity>();

        /// <summary>
        /// Adding the Ticket......
        /// </summary>
        /// <param name="student"></param>
        /// <returns></returns>
        public bool Add_dal(Ticketentity student)
        {
            bool ticketAdded = false;
            try
            {
                tc.Add(student);
                ticketAdded = true;
            }
            catch (TicketNotFoundException ex)
            {
                throw ex;
            }

            return ticketAdded;
        }

        /// <summary>
        /// Display Method......
        /// </summary>
        /// <returns></returns>
        /// 
        public List<Ticketentity> GetAll_dal()
        {
            return tc;
        }

        /// <summary>
        /// Search Method.........
        /// </summary>
        /// <param name="PNRNumber"></param>
        /// <returns></returns>

        public Ticketentity searchticket_dal(int PNRNumber)
        {
            try
            {
                Ticketentity searchticket = null;
                foreach (var ticket in tc)
                {
                    if (ticket.PNRNumber == PNRNumber)
                    {
                        searchticket = ticket;
                    }

                }
                return searchticket;
            }
            catch (TicketNotFoundException ex)
            {
                throw ex;
            }

        }

        public static bool SerializeData()
        {


            try
            {
                FileStream fs = new FileStream("TicketDetails.dat", FileMode.Create);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fs, tc);
                fs.Close();
            }
            catch (TicketNotFoundException ex)
            {
                throw ex;

            }
            return true;
        }

        public static List<Ticketentity> DeserializeData()
        {
            FileStream stream = new FileStream("TicketDetails.dat", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            tc = formatter.Deserialize(stream) as List<Ticketentity>;
            return tc;
        }
    }
}
