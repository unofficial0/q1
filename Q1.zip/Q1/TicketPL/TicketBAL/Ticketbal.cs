﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicketDAL;
using TicketEntity;
using TicketException;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;


namespace TicketBAL
{
    public class Ticketbal
    {
        public static List<Ticketentity> tck = new List<Ticketentity>();
        public static object tickets;


        private static bool ValidateStudent(Ticketentity ticket)
        {
            StringBuilder sb = new StringBuilder();
            bool validticket = true;

            //if (!(Regex.IsMatch(ticket.PNRNumber.ToString(), @"^[8][0-9]{6}$")))
            //{
            //    validticket = false;
            //    sb.Append("PNR Number must start with 8" + Environment.NewLine);
            //}

            if ((ticket.Type != "SLEEPER") && (ticket.Type != "3AC") && (ticket.Type != "2AC") && (ticket.Type != "1AC"))
            {
                validticket = false;
                sb.Append(Environment.NewLine + "Type of Classes has to be SLEEPER, 3AC , 2AC , 1AC and should be in same format as capitals");

            }


            if (validticket == false)
                throw new TicketNotFoundException(sb.ToString());
            return validticket;
        }
        /// <summary>
        /// Add Method.......
        /// </summary>
        /// <param name="newticket"></param>
        /// <returns></returns>
        public static  bool AddTicket(Ticketentity newticket)
        {
            bool ticketAdded = false;
            try
            {
                if (ValidateStudent(newticket))
                {
                    Ticketdal ticketdal = new Ticketdal();
                    ticketAdded = ticketdal.Add_dal(newticket);
                }
            }
            catch (TicketNotFoundException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ticketAdded;
        }

        /// <summary>
        /// Display method.......
        /// </summary>
        /// <returns></returns>

        public static List<Ticketentity> GetAll_bal()
        {
            List<Ticketentity> ticketList = null;
            try
            {
                Ticketdal ticketdal = new Ticketdal();
                ticketList = ticketdal.GetAll_dal();
            }
            catch (TicketNotFoundException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ticketList;
        }

        // Searching the data from Tickets on the basis of PNR Number
        /// <summary>
        /// Search method......
        /// </summary>
        /// <param name="PNRNumber"></param>
        /// <returns></returns>
        public static Ticketentity SearchticketBAL(int PNRNumber)
        {
            Ticketentity searchTicket = null;
            try
            {
                Ticketdal ticketDAL = new Ticketdal();
                searchTicket = ticketDAL.searchticket_dal(PNRNumber);
            }
            catch (TicketNotFoundException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return searchTicket;
        }


        /// <summary>
        /// Serielize Data.........
        /// </summary>
        /// <returns></returns>
        /// 
        public static bool SerializeData()
        {
            return Ticketdal.SerializeData();
        }

        /// <summary>
        /// Deserielize Data.........
        /// </summary>
        /// <returns></returns>

        public static List<Ticketentity> DeserializeData()
        {

            return Ticketdal.DeserializeData();
        }
    }
}
